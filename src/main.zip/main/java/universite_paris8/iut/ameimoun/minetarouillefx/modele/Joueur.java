package universite_paris8.iut.ameimoun.minetarouillefx.modele;

import universite_paris8.iut.ameimoun.minetarouillefx.utils.Constantes;

public class Joueur extends Personnage {
    public Joueur() {
        super(30, 50, 50, "Joueur");
    }

    public void creuser(){
    //s'il a une pelle seulement
    }


}