package universite_paris8.iut.ameimoun.minetarouillefx.vue;

public class VueParametres {
    //Ajouter dans le jeu un menu paramètres qui s'ouvre quand on appuie sur echap





}
