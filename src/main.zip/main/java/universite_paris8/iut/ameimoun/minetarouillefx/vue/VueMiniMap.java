package universite_paris8.iut.ameimoun.minetarouillefx.vue;

import javafx.fxml.FXML;
import javafx.scene.shape.Circle;




public class VueMiniMap {

}
