package universite_paris8.iut.ameimoun.minetarouillefx.modele;

public class Objet {
}
