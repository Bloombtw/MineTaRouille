package universite_paris8.iut.ameimoun.minetarouillefx.modele;

import java.util.ArrayList;

public class Personnage {
    int x;
    int y;
    private double pointsDeVie;
    private String nom;
    private double vitesseDeplacement;
    private double satiete;
    private ArrayList<Objet> inventaire;
}
